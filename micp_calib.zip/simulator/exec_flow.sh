cd build
./sim 1 0.5 0.1 1 3
./validate | gnuplot
